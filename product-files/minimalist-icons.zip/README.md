# Minimalist Icon Pack - 500 Icons

## Categories (500 total)
- Interface (100 icons)
- Business (80 icons)
- Technology (90 icons)
- Social Media (60 icons)
- E-commerce (70 icons)
- Navigation (50 icons)
- Communication (50 icons)

## File Formats
- SVG (vector)
- PNG (24px, 48px, 96px)
- AI (Adobe Illustrator)
- Sketch symbols

## Style Features
- 2px stroke weight
- Rounded corners
- Consistent sizing
- Pixel perfect
- Scalable vectors