# 80s Retro Asset Pack

## Included Assets
- Palm trees (10 variations)
- Neon signs (15 designs)
- Chrome text effects
- Sunset gradients
- Geometric shapes
- Retro cars (5 models)

## Style Features
- Vibrant neon colors
- Chrome materials
- Synthwave aesthetics
- Vaporwave elements
- Grid patterns

## File Formats
- 3D Models: FBX, OBJ
- Textures: PNG, TGA
- Materials: PBR workflow