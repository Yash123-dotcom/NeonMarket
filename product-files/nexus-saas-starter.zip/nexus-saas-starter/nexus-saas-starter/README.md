

# 🚀 NEXUS — Modern SaaS Starter Kit (v2.0)

> **Launch your next SaaS in days, not months.**
> A production-ready starter kit built with **Next.js 15**, **Stripe Subscriptions**, **Clerk Authentication**, and **Prisma**.

---

## 📌 What is Nexus?

**Nexus** is a fully wired SaaS foundation that eliminates repetitive setup work so you can focus on building your product’s core features.

Instead of spending weeks configuring authentication, payments, databases, and UI, Nexus gives you a **battle-tested starting point** that just works.

---

## 🧱 Tech Stack

| Feature            | Technology                                     |
| ------------------ | ---------------------------------------------- |
| **Framework**      | Next.js 15 (App Router)                        |
| **Authentication** | Clerk (Google, Email, GitHub pre-configured)   |
| **Database**       | PostgreSQL + Prisma ORM                        |
| **Payments**       | Stripe Subscriptions (Monthly / Yearly Toggle) |
| **Styling**        | Tailwind CSS + Lucide Icons                    |
| **Deployment**     | Vercel-ready                                   |
| **Marketing**      | Conversion-focused landing page                |

---

## ⚡ Quick Start

### 1️⃣ Install Dependencies

```bash
npm install
# or
yarn install
```

---

### 2️⃣ Environment Setup

Rename `.env.example` → `.env` and add your credentials:

```env
# Database (Neon or Supabase recommended)
DATABASE_URL="postgresql://user:password@host:5432/db"

# Clerk Authentication
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...

# Stripe Payments
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
```

---

### 3️⃣ Connect the Database

Nexus uses **Prisma** to manage users and subscriptions.

📍 Schema location:

```
/prisma/schema.prisma
```

Push the schema to your database:

```bash
npx prisma db push
```

---

### 4️⃣ Run the App

```bash
npm run dev
```

Visit 👉 [http://localhost:3000]
Your SaaS landing page should now be live 🎉

---

## 💳 Stripe Setup (Subscriptions)

The pricing system is already implemented — you just need to add your **Stripe Price IDs**.

### Steps:

1. Open your **Stripe Dashboard**
2. Go to **Products**
3. Create a product (e.g., `Pro Plan`)
4. Add two prices:

   * **Monthly** (e.g., $29)
   * **Yearly** (e.g., $290)
5. Copy both **Price IDs** (`price_XXXX`)
6. Paste them into:

   ```
   /lib/stripe.ts
   ```

---

### 🔁 Pricing Toggle Logic

The pricing table automatically switches between monthly and yearly plans:

```tsx
// /components/PricingTable.tsx
const [isYearly, setIsYearly] = useState(false);

<div className="text-4xl font-black mb-6">
  ${isYearly ? "19" : "29"}
  <span className="text-lg font-medium text-gray-500">/mo</span>
</div>
```

No backend changes required — it’s already wired to Stripe Checkout.

---

## 🚀 Deploying to Vercel

Nexus is optimized for **Vercel deployment**.

### Steps:

1. Push the project to a **GitHub repository**
2. Go to **Vercel → Add New Project**
3. Import your repo
4. Add all `.env` variables to **Vercel Environment Variables**
5. Click **Deploy**

Your SaaS will be live in minutes ⚡

---

## 📂 Project Structure

```plaintext
/app
  /api            # Backend logic (Stripe webhooks, etc.)
  /dashboard      # Auth-protected app area
  page.tsx        # Landing page

/components
  PricingTable    # Subscription UI
  Navbar          # Responsive navigation

/lib
  db.ts           # Prisma DB helper
  stripe.ts       # Stripe configuration

/prisma
  schema.prisma   # Database schema
```

---

## 🧠 What You Can Build With Nexus

* SaaS dashboards
* Subscription-based products
* AI tools
* Internal tools
* Startup MVPs
* B2B platforms

---

## 🏁 Final Notes

You’re not starting from zero — you’re starting from **production-ready**.

If you customize this well, Nexus can easily power a **real startup**.

Happy shipping 🚀
