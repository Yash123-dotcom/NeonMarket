"use client";

import { useState } from "react";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button"; // Assumes they have a button component

export const PricingTable = () => {
  const [isYearly, setIsYearly] = useState(false);

  return (
    <section className="py-24 bg-black text-white">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-5xl font-black mb-6">Simple, Transparent Pricing</h2>
        
        {/* Toggle Switch */}
        <div className="flex items-center justify-center gap-4 mb-16">
          <span className={`text-sm font-bold ${!isYearly ? "text-white" : "text-gray-500"}`}>Monthly</span>
          <button 
            onClick={() => setIsYearly(!isYearly)}
            className="w-16 h-8 bg-gray-800 rounded-full p-1 relative transition-colors"
          >
            <div className={`w-6 h-6 bg-purple-500 rounded-full transition-transform ${isYearly ? "translate-x-8" : "translate-x-0"}`} />
          </button>
          <span className={`text-sm font-bold ${isYearly ? "text-white" : "text-gray-500"}`}>
            Yearly <span className="text-purple-400 text-xs ml-1">(Save 20%)</span>
          </span>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {/* FREE PLAN */}
          <div className="bg-gray-900/50 border border-gray-800 p-8 rounded-2xl text-left">
            <h3 className="font-bold text-gray-400 mb-2">Hobby</h3>
            <div className="text-4xl font-black mb-6">$0<span className="text-lg font-medium text-gray-500">/mo</span></div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-green-500" /> 5 AI Generations</li>
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-green-500" /> Public Projects</li>
            </ul>
            <Button className="w-full bg-gray-800 hover:bg-gray-700">Get Started</Button>
          </div>

          {/* PRO PLAN (Highlighted) */}
          <div className="relative bg-black border border-purple-500 p-8 rounded-2xl text-left transform md:-translate-y-4 shadow-[0_0_50px_-10px_rgba(168,85,247,0.3)]">
            <div className="absolute top-0 right-0 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-xl">POPULAR</div>
            <h3 className="font-bold text-purple-400 mb-2">Pro</h3>
            <div className="text-4xl font-black mb-6">
              ${isYearly ? "19" : "29"}
              <span className="text-lg font-medium text-gray-500">/mo</span>
            </div>
            <p className="text-sm text-gray-400 mb-6">For serious creators building next-gen apps.</p>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-purple-400" /> Unlimited AI Generations</li>
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-purple-400" /> Priority Support</li>
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-purple-400" /> Analytics Dashboard</li>
            </ul>
            <Button className="w-full bg-purple-600 hover:bg-purple-500 font-bold">Upgrade to Pro</Button>
          </div>

           {/* ENTERPRISE PLAN */}
           <div className="bg-gray-900/50 border border-gray-800 p-8 rounded-2xl text-left">
            <h3 className="font-bold text-gray-400 mb-2">Enterprise</h3>
            <div className="text-4xl font-black mb-6">$99<span className="text-lg font-medium text-gray-500">/mo</span></div>
            <ul className="space-y-4 mb-8">
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-green-500" /> API Access</li>
              <li className="flex items-center gap-3 text-sm"><Check className="w-4 h-4 text-green-500" /> SSO Integration</li>
            </ul>
            <Button className="w-full bg-gray-800 hover:bg-gray-700">Contact Sales</Button>
          </div>
        </div>
      </div>
    </section>
  );
};