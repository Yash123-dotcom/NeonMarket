import { PricingTable } from "@/components/PricingTable";
import Link from "next/link";
import { ArrowRight, Sparkles } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-black text-white selection:bg-purple-500">
      
      {/* HERO SECTION */}
      <section className="pt-32 pb-20 px-6 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-900/30 border border-purple-500/30 text-purple-400 text-sm font-bold mb-8">
          <Sparkles className="w-4 h-4" />
          <span>v2.0 is now live</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-black tracking-tight mb-8">
          Build your SaaS <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
            at warp speed.
          </span>
        </h1>
        
        <p className="text-xl text-gray-400 max-w-2xl mx-auto mb-12">
          The production-ready starter kit featuring Stripe Subscriptions, Clerk Auth, and Prisma. Stop configuring, start shipping.
        </p>
        
        <div className="flex justify-center gap-4">
          <Link href="/dashboard" className="px-8 py-4 bg-white text-black font-bold rounded-full hover:bg-gray-200 transition flex items-center gap-2">
            Get Started <ArrowRight className="w-4 h-4" />
          </Link>
          <Link href="#" className="px-8 py-4 bg-white/10 text-white font-bold rounded-full hover:bg-white/20 transition">
            View Documentation
          </Link>
        </div>
      </section>

      {/* PRICING SECTION */}
      <PricingTable />
      
    </main>
  );
}