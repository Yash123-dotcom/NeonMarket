# 📟 The Hacker Portfolio & UI Kit (v1.0)

> **Turn your portfolio into a cyberpunk masterpiece.**
> Includes a fully interactive Command Line Interface (CLI) and a reusable Matrix Typing Effect for your headers.

---

## 📦 What's Inside?

1.  **`<Terminal />`**: A functional, interactive shell that visitors can type into. Great for displaying "About Me" or "Skills" in a geeky way.
2.  **`<MatrixText />`**: A wrapper component that applies a "hacker typing" animation to any text on your site.

## 🛠 Features
- [x] **Real Interaction:** The terminal accepts user input and executes commands.
- [x] **Auto-Typing Effects:** Make your headers look like they are being decrypted in real-time.
- [x] **Zero Dependencies:** Built with pure React hooks and Tailwind CSS.
- [x] **Retro Styling:** Green phosphor glow, blinking cursors, and CRT vibes.

---

## 🚀 Installation

1.  **Unzip** the folder.
2.  **Copy** the 2 component files into your project:
    * `components/Terminal.tsx`
    * `components/MatrixText.tsx`

---

## 💻 Usage Guide

### 1. The Matrix Text (For Headers)
Use this to make your headlines cool. It supports typing speed and start delays.

**Props:**
* `text` (string): The text to display.
* `speed` (number): Typing speed in ms (lower is faster).
* `delay` (number): How long to wait before starting (in ms).

```tsx
import { MatrixText } from "@/components/MatrixText";

export default function Hero() {
  return (
    <h1 className="text-5xl font-bold">
      {/* Types "WAKE UP NEO..." slowly after 1 second */}
      <MatrixText text="WAKE UP NEO..." speed={100} delay={1000} />
    </h1>
  );
}
2. The Terminal (Interactive)
The main attraction. Drop this anywhere on your page.

TypeScript

import { Terminal } from "@/components/Terminal";

export default function About() {
  return (
    <div className="max-w-3xl mx-auto py-20">
      <Terminal />
    </div>
  );
}
⚙️ Configuration
Customizing Terminal Commands
Open Terminal.tsx and look for the commands object. This is where you define what happens when a user types.

TypeScript

// Inside Terminal.tsx
const commands: Record<string, string> = {
  help: "Try typing: skills, contact, or secret",
  
  // Update these with your real info!
  about: "I am a Full Stack Dev based in San Francisco.",
  skills: "React, Next.js, TypeScript, and excessive coffee drinking.",
  contact: "email@example.com",
  
  // Add secret easter eggs
  sudo: "Nice try, but you have no power here.",
};
Changing Colors
Both components use standard Tailwind CSS classes (e.g., text-green-400, border-green-500).

Want a Red "Sith" Theme? -> Find/Replace green with red in the files.

Want a Blue "System" Theme? -> Find/Replace green with cyan.

📜 License
Commercial Use Allowed: ✅ You can use this in your personal portfolio. ✅ You can use this in client projects. ❌ You cannot resell this code as a standalone template.

Enjoy building the future.