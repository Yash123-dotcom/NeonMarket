"use client";

import { useState, useEffect } from "react";

interface MatrixTextProps {
  text: string;
  speed?: number; // How fast it types (ms)
  delay?: number; // Wait before starting (ms)
  className?: string; // Add extra styles if needed
}

export const MatrixText = ({ text, speed = 50, delay = 0, className = "" }: MatrixTextProps) => {
  const [displayedText, setDisplayedText] = useState("");
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const startTimeout = setTimeout(() => {
      setStarted(true);
    }, delay);

    return () => clearTimeout(startTimeout);
  }, [delay]);

  useEffect(() => {
    if (!started) return;

    let i = 0;
    const intervalId = setInterval(() => {
      if (i < text.length) {
        setDisplayedText((prev) => text.slice(0, i + 1));
        i++;
      } else {
        clearInterval(intervalId);
      }
    }, speed);

    return () => clearInterval(intervalId);
  }, [text, speed, started]);

  return (
    <span className={`font-mono text-green-400 drop-shadow-[0_0_8px_rgba(74,222,128,0.6)] ${className}`}>
      {displayedText}
      {/* The Blinking Cursor */}
      <span className="animate-pulse inline-block w-2 h-4 bg-green-500 ml-1 align-middle" />
    </span>
  );
};