import { Terminal } from "@/components/Terminal";
import { MatrixText } from "@/components/MatrixText";

export default function PortfolioPage() {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-10 gap-10">
      
      {/* 1. Use it for a Big Header */}
      <h1 className="text-4xl md:text-6xl font-bold text-center">
        <MatrixText text="WAKE UP, NEO..." speed={100} />
      </h1>

      {/* 2. Use it for a Subtitle (with a delay) */}
      <div className="text-xl text-gray-400">
        <MatrixText text="The system is watching you." delay={2000} speed={50} />
      </div>

      {/* 3. The Interactive Terminal */}
      <Terminal />
      
    </div>
  );
}