"use client";

import React, { useState, useEffect, useRef } from "react";

export const Terminal = () => {
  const [history, setHistory] = useState<string[]>(["Welcome to NeoTerm v1.0. Type 'help' to start."]);
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const commands: Record<string, string> = {
    help: "Available commands: about, projects, contact, clear",
    about: "I am a Full Stack Developer building the future of the web.",
    projects: "1. NeonMarket (Next.js) \n2. CyberDecks (React Native)",
    contact: "Email: dev@neon.com | GitHub: @neondev",
    clear: "CLEAR",
  };

  const handleCommand = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      const cmd = input.trim().toLowerCase();
      const response = commands[cmd] || `Command not found: ${cmd}`;

      if (response === "CLEAR") {
        setHistory([]);
      } else {
        setHistory([...history, `> ${input}`, response]);
      }
      setInput("");
    }
  };

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  return (
    <div className="w-full max-w-3xl mx-auto h-[500px] bg-black/90 border border-green-500/30 rounded-lg p-4 font-mono text-green-400 shadow-[0_0_20px_rgba(34,197,94,0.2)] overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2 mb-4 border-b border-green-500/20 pb-2">
        <div className="w-3 h-3 rounded-full bg-red-500" />
        <div className="w-3 h-3 rounded-full bg-yellow-500" />
        <div className="w-3 h-3 rounded-full bg-green-500" />
        <span className="ml-2 text-xs text-green-600">user@neon-os:~</span>
      </div>

      {/* Output Area */}
      <div className="flex-1 overflow-y-auto space-y-2 scrollbar-hide">
        {history.map((line, i) => (
          <pre key={i} className="whitespace-pre-wrap font-mono">{line}</pre>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input Area */}
      <div className="flex items-center gap-2 mt-2">
        <span className="text-green-500">➜</span>
        <span className="text-cyan-400">~</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleCommand}
          className="bg-transparent border-none outline-none text-green-100 flex-1 font-mono"
          autoFocus
        />
      </div>
    </div>
  );
};