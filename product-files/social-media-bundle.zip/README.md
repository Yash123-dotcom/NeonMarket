# Social Media Graphics Bundle

## 200+ Templates Included
- Instagram posts (50)
- Instagram stories (40)
- Facebook posts (30)
- Twitter headers (20)
- LinkedIn banners (25)
- YouTube thumbnails (35)

## File Formats
- PSD (Photoshop)
- AI (Illustrator)
- Canva templates
- Figma files

## Categories
- Business & Corporate
- Creative & Artistic
- E-commerce & Sales
- Personal Branding
- Event Promotion

## Features
- Easy text editing
- Smart objects
- Color variations
- Font recommendations