# Particle Magic - Fire & Smoke

## 30 Effects Included
- Realistic fire effects
- Smoke simulations
- Explosion particles
- Magical effects
- Environmental particles

## Engine Support
- Unity Particle System
- Unreal Niagara
- Blender
- After Effects

## Customizable Parameters
- Size and scale
- Color gradients
- Emission rates
- Lifetime curves
- Velocity patterns